// server.js
const express = require("express")
const cors = require("cors")
const fs = require("fs")
const path = require("path")
const helmet = require("helmet")
const compression = require("compression")
const morgan = require("morgan")
const rateLimit = require("express-rate-limit")
const swaggerUi = require("swagger-ui-express")

const app = express()
const PORT = process.env.PORT || 3000

// Middleware
app.use(cors())
app.use(express.static(".")) // Sajikan index.html, dll
app.use(helmet({ crossOriginResourcePolicy: false }))
app.use(compression())
app.use(morgan("dev"))

// API: GET /number/list
app.get("/number/list", (req, res) => {
  try {
    res.set("Cache-Control", "no-store")
    const data = JSON.parse(fs.readFileSync(path.join(__dirname, "number.json"), "utf8"))
    res.json({
      success: true,
      count: data.numbers.length,
      numbers: data.numbers,
    })
  } catch (err) {
    console.error(err)
    res.status(500).json({ success: false, error: "Gagal memuat data" })
  }
})

// API: GET /number/validate/:number
app.get("/number/validate/:number", (req, res) => {
  const rawNumber = req.params.number
  const cleanNumber = rawNumber.replace(/\D/g, "")

  try {
    res.set("Cache-Control", "no-store")
    const data = JSON.parse(fs.readFileSync(path.join(__dirname, "number.json"), "utf8"))
    const valid = data.numbers.includes(cleanNumber)
    res.json({ valid, number: cleanNumber })
  } catch (err) {
    res.status(500).json({ error: "Server error" })
  }
})

const clients = new Set() // menampung koneksi SSE aktif
const numbersFilePath = path.join(__dirname, "number.json")

function readNumbersSafe() {
  try {
    const raw = fs.readFileSync(numbersFilePath, "utf8")
    const data = JSON.parse(raw)
    const numbers = Array.isArray(data?.numbers) ? data.numbers : []
    return { numbers, count: numbers.length }
  } catch (e) {
    return { numbers: [], count: 0, error: "Gagal membaca number.json" }
  }
}

// SSE endpoint: push data awal dan update saat file berubah
app.get("/number/stream", (req, res) => {
  res.setHeader("Content-Type", "text/event-stream; charset=utf-8")
  res.setHeader("Cache-Control", "no-cache, no-transform")
  res.setHeader("Connection", "keep-alive")
  res.setHeader("X-Accel-Buffering", "no")
  res.flushHeaders?.()

  const initial = readNumbersSafe()
  res.write(`data: ${JSON.stringify({ ...initial, ts: Date.now() })}\n\n`)

  clients.add(res)

  // heartbeat tiap 25s agar koneksi tetap hidup melalui proxy
  const heartbeat = setInterval(() => {
    try {
      res.write(`: ping ${Date.now()}\n\n`)
    } catch {
      clearInterval(heartbeat)
    }
  }, 25000)

  req.on("close", () => {
    clients.delete(res)
    clearInterval(heartbeat)
    try {
      res.end()
    } catch {}
  })
})

// pantau perubahan file dan broadcast ke semua klien SSE
fs.watchFile(numbersFilePath, { interval: 1000 }, () => {
  const payload = readNumbersSafe()
  const data = `data: ${JSON.stringify({ ...payload, ts: Date.now() })}\n\n`
  for (const client of clients) {
    try {
      client.write(data)
    } catch {
      // jika gagal menulis, hentikan dan keluarkan dari set
      try {
        client.end()
      } catch {}
      clients.delete(client)
    }
  }
})

app.get("/health", (_req, res) => {
  res.set("Cache-Control", "no-store")
  res.json({ ok: true, uptime: process.uptime(), ts: Date.now() })
})

app.use(express.json())
const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
})
app.use(["/number", "/health"], apiLimiter)

const swaggerSpec = {
  openapi: "3.0.1",
  info: {
    title: "API Number",
    version: "1.0.0",
    description:
      "API Express untuk menampilkan dan memvalidasi daftar nomor dari file number.json dengan dukungan realtime (SSE).",
  },
  servers: [{ url: `http://localhost:${PORT}`, description: "Local" }],
  paths: {
    "/health": {
      get: {
        summary: "Health check",
        responses: { 200: { description: "OK" } },
      },
    },
    "/number/list": {
      get: {
        summary: "Ambil daftar nomor",
        responses: {
          200: {
            description: "Sukses",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean" },
                    count: { type: "number" },
                    numbers: { type: "array", items: { type: "string" } },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/number/validate/{number}": {
      get: {
        summary: "Validasi nomor tertentu",
        parameters: [
          {
            name: "number",
            in: "path",
            required: true,
            schema: { type: "string", example: "6281234567890" },
          },
        ],
        responses: {
          200: {
            description: "Status valid",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    valid: { type: "boolean" },
                    number: { type: "string" },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/number/stream": {
      get: {
        summary: "Realtime stream daftar nomor (SSE)",
        responses: { 200: { description: "EventStream" } },
      },
    },
  },
}
app.use("/docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec))

// Jalankan server
app.listen(PORT, () => {
  console.log(`🟢 Server berjalan di http://localhost:${PORT}`)
  console.log(`📄 Buka: http://localhost:${PORT}`)
  console.log(`📡 API: http://localhost:${PORT}/number/list`)
  console.log(`🧪 Health: http://localhost:${PORT}/health`)
  console.log(`📘 Docs: http://localhost:${PORT}/docs`)
})
